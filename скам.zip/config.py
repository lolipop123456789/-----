token = '1885268861:AAFWrxCRFwnhBf-0f_D-pPI_vZl_zKXh0GE' # Токен бота
loginbot = 'kazingbot' # Логин бота телеграм

QIWI_PUBLICKEY = '48e7qUxn9T7RyYE1MVZswX1FRSbE6iyCj2gCRwwF3Dnh5XrasNTx3BGPiMsyXQFNKQhvukniQG8RTVhYm3iPtjgeoCh8nEGWUoBE36oEzSWbGxYKdUmHAxAk45Rbm3UhNRGGzFkTRSeNJNxo4RtQd5MAPAqDYVPbkhSySqgnpjWZtuaoGTSkkvMgxmLVt' #p2p public key
QIWI_TOKEN = 'xxxxxxxx' # токен киви
QIWI_NUMBER = '77777777777' # Номер киви без +

admin_id = 1430448443 # Ваш айди

price = 190 # Цена за доступ